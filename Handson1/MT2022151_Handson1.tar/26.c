/*
  Name : Prafull Pandey
  Roll no : MT2022151
  
  Que: 26 Write a program to execute an executable program.
a. use some executable program
b. pass some input to an executable program. (for example execute an executable of $./a.out name)
*/
#include<stdio.h>

void main(int argc , char * argv[])
{
	printf("This is a sample file for 26.1\n");
	printf("Input from 26.1.c: %s\n",argv[1]);
}	

