/*
    Name : Prafull Pandey
    Roll no : MT2022151
    
    Que : 18. Write a program to perform Record locking.
    a. Implement write lock
   
    Create three records in a file. Whenever you access a particular record, first lock it then modify/access
    to avoid race condition.
*/


#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>

void main() {
           struct flock lock;
           int fd;
           fd = open("database", O_RDWR);
           lock.l_type = F_RDLCK;
           lock.l_whence = SEEK_SET;
           lock.l_start = 0;
           lock.l_len = 0;
           lock.l_pid = getpid();
           
           printf("Before entering into critical section\n");
           fcntl(fd, F_SETLKW, &lock);
           printf("Inside the critical section \n");
           printf("Enter to unlock\n");
           getchar();
           
           lock.l_type=F_UNLCK; // now unlock 
           fcntl(fd,F_SETLK,&lock);
           printf("finish\n");
}
